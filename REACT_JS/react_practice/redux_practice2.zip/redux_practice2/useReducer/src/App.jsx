// import CakeContainer from "./components/CakeContainer"

// import Axios_Get from "./pages/Axios_Get"
import Axios_Post from "./pages/Axios_Post"

// import ProductData from "./components/ProductData"


function App() {

  return (
    <>
     {/* <CakeContainer/> */}
     {/* <ProductData/> */}
     {/* <Axios_Get/> */}
     <Axios_Post/>
    </>
  )
}

export default App
